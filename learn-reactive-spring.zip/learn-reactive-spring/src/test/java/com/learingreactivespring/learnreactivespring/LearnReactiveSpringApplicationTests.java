package com.learingreactivespring.learnreactivespring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnReactiveSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
