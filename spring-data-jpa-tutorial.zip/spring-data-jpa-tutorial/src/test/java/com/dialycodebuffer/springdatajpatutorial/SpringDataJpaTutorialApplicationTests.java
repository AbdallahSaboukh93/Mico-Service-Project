package com.dialycodebuffer.springdatajpatutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpaTutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
