package com.isfp.jasperserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JasperserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
