package com.isfp.jasperserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JasperserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(JasperserverApplication.class, args);
	}

}
