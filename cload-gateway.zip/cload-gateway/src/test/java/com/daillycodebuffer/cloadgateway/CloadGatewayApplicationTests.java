package com.daillycodebuffer.cloadgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloadGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
